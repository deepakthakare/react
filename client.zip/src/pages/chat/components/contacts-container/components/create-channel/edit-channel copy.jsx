import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import MultipleSelector from "@/components/ui/multipleselect";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import apiClient from "@/lib/api-client";
import { GET_ALL_CONTACTS, GET_CHANNEL_DETAILS, UPDATE_CHANNEL } from "@/lib/constants";
import { useSocket } from "@/contexts/SocketContext";
import { useAppStore } from "@/store";
import { Input } from "@/components/ui/input";

const EditChannel = ({ contact, onClose }) => {
  const [allContacts, setAllContacts] = useState([]);
  const [selectedContacts, setSelectedContacts] = useState([]);
  const [channelName, setChannelName] = useState("");
  const socket = useSocket();
  const { updateChannel } = useAppStore();

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch all available contacts
        const contactsResponse = await apiClient.get(GET_ALL_CONTACTS, {
          withCredentials: true,
        });
        
        // Fetch channel details
        const channelResponse = await apiClient.get(
          `${GET_CHANNEL_DETAILS}/${contact._id}`,
          { withCredentials: true }
        );

        const { channel } = channelResponse.data;
        
        // Map contacts to selector format
        const mappedContacts = contactsResponse.data.contacts.map(contact => ({
          value: contact.value,
          label: contact.label
        }));

        // Map existing members to selected format
        const currentMembers = channel.members.map(member => ({
          value: member._id,
          label: `${member.firstName} ${member.lastName}`
        }));

        setAllContacts(mappedContacts);
        setSelectedContacts(currentMembers);
        setChannelName(channel.name);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, [contact]);

  const handleUpdate = async () => {
    try {
      const response = await apiClient.put(
        `${UPDATE_CHANNEL}/${contact._id}`,
        {
          name: channelName,
          members: selectedContacts.map(c => c.value),
        },
        { withCredentials: true }
      );

      if (response.status === 200) {
        updateChannel(response.data.channel);
        socket.emit("channel-updated", response.data.channel);
        onClose();
      }
    } catch (error) {
      console.error("Update failed:", error.response?.data || error.message);
    }
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="bg-[#181920] border-none text-white w-[400px] h-max flex flex-col">
        <DialogHeader>
          <DialogTitle>Edit Channel</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <Input
            placeholder="Channel Name"
            className="rounded-lg py-6 px-4 bg-[#2c2e3b] border-none"
            value={channelName}
            onChange={(e) => setChannelName(e.target.value)}
          />

          <MultipleSelector
            className="rounded-lg bg-[#2c2e3b] border-none py-2 text-white"
            defaultOptions={allContacts}
            placeholder="Select Members"
            value={selectedContacts}
            onChange={setSelectedContacts}
            emptyIndicator={
              <p className="text-center text-lg leading-10 text-gray-400">
                No contacts found
              </p>
            }
          />
        </div>

        <div className="flex gap-2 mt-4">
          <Button
            onClick={handleUpdate}
            className="w-full bg-lime-700 hover:bg-lime-600 transition-all"
          >
            Save Changes
          </Button>
          <Button
            onClick={onClose}
            className="w-full bg-red-700 hover:bg-red-600 transition-all"
          >
            Cancel
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default EditChannel;