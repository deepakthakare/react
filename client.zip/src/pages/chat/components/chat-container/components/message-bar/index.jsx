import { IoSend } from "react-icons/io5";
import { GrAttachment } from "react-icons/gr";
import { RiEmojiStickerLine } from "react-icons/ri";
import { IoCloseSharp } from "react-icons/io5";
import EmojiPicker from "emoji-picker-react";
import { useEffect, useRef, useState } from "react";
import { useAppStore } from "@/store";
import { useSocket } from "@/contexts/SocketContext";
import { MESSAGE_TYPES, UPLOAD_FILE } from "@/lib/constants";
import apiClient from "@/lib/api-client";

const MessageBar = () => {
  const emojiRef = useRef();
  const fileInputRef = useRef();
  const {
    selectedChatData,
    userInfo,
    selectedChatType,
    setIsUploading,
    setFileUploadProgress,
    repliedMessage,
    clearRepliedMessage,
  } = useAppStore();
  
  const [message, setMessage] = useState("");
  const [emojiPickerOpen, setEmojiPickerOpen] = useState(false);
  const socket = useSocket();

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (emojiRef.current && !emojiRef.current.contains(event.target)) {
        setEmojiPickerOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [emojiRef]);

  const handleAddEmoji = (emoji) => {
    setMessage((msg) => msg + emoji.emoji);
  };

  const handleMessageChange = (event) => {
    setMessage(event.target.value);
  };

  const sendMessage = (messageData) => {
    if (selectedChatType === "contact") {
      socket.emit("sendMessage", {
        ...messageData,
        replyTo: repliedMessage?._id || null,
      });
    } else if (selectedChatType === "channel") {
      socket.emit("send-channel-message", {
        ...messageData,
        channelId: selectedChatData._id,
        replyTo: repliedMessage?._id || null,
      });
    }
  };

  const handleSendMessage = async () => {
    if (!message.trim() && !repliedMessage) return;

    const messageData = {
      sender: userInfo.id,
      content: message,
      messageType: MESSAGE_TYPES.TEXT,
      recipient: selectedChatType === "contact" ? selectedChatData._id : null,
    };

    sendMessage(messageData);
    setMessage("");
    clearRepliedMessage();
  };

  const handleAttachmentChange = async (event) => {
    try {
      const file = event.target.files[0];
      if (!file) return;

      const formData = new FormData();
      formData.append("file", file);
      setIsUploading(true);

      const response = await apiClient.post(UPLOAD_FILE, formData, {
        withCredentials: true,
        onUploadProgress: (progress) => {
          setFileUploadProgress(Math.round((100 * progress.loaded) / progress.total));
        },
      });

      if (response.data?.filePath) {
        const messageData = {
          sender: userInfo.id,
          messageType: MESSAGE_TYPES.FILE,
          fileUrl: response.data.filePath,
          recipient: selectedChatType === "contact" ? selectedChatData._id : null,
        };

        sendMessage(messageData);
        clearRepliedMessage();
      }
    } catch (error) {
      console.error("File upload failed:", error);
    } finally {
      setIsUploading(false);
    }
  };

  const handleAttachmentClick = () => {
    fileInputRef.current?.click();
  };
  return (
    <div className="min-h-[10vh] bg-[#1c1d25] flex flex-col">
      {/* Reply Preview */}
      {repliedMessage && (
        <div className="bg-[#2a2b33] p-2 mb-2 flex justify-between items-center flex-shrink-0">
          <div className="text-sm text-gray-400 truncate max-w-[85%]">
            Replying to: {repliedMessage.content || "File attachment"}
          </div>
          <button
            onClick={clearRepliedMessage}
            className="text-gray-400 hover:text-white p-1 rounded-full hover:bg-gray-700/20"
            aria-label="Cancel reply"
          >
            <IoCloseSharp className="text-lg" />
          </button>
        </div>
      )}
  
      {/* Input Area */}
      <div className="flex-1 flex items-center px-8 gap-6 min-h-[60px]">
        <div className="flex-1 flex bg-[#2a2b33] rounded-md items-center gap-5 pr-5 mb-2">
          <input
            type="text"
            className="flex-1 p-5 bg-transparent rounded-md focus:outline-none"
            placeholder="Enter message"
            value={message}
            onChange={handleMessageChange}
            onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
          />
          
          <button
            className="text-neutral-300 hover:text-white transition-colors"
            onClick={handleAttachmentClick}
            aria-label="Attach file"
          >
            <GrAttachment className="text-2xl" />
          </button>
          
          <input
            type="file"
            className="hidden"
            ref={fileInputRef}
            onChange={handleAttachmentChange}
          />
  
          <div className="relative">
            <button
              className="text-neutral-300 hover:text-white transition-colors"
              onClick={() => setEmojiPickerOpen(!emojiPickerOpen)}
              aria-label="Open emoji picker"
            >
              <RiEmojiStickerLine className="text-2xl" />
            </button>
            
            {emojiPickerOpen && (
              <div className="absolute bottom-16 right-0" ref={emojiRef}>
                <EmojiPicker
                  theme="dark"
                  onEmojiClick={handleAddEmoji}
                  autoFocusSearch={false}
                />
              </div>
            )}
          </div>
        </div>
  
        <button
          className="bg-[#4a720c] rounded-md p-5 hover:bg-[#3a5a0a] transition-colors"
          onClick={handleSendMessage}
          aria-label="Send message"
        >
          <IoSend className="text-2xl" />
        </button>
      </div>
    </div>
  );
};

export default MessageBar; 