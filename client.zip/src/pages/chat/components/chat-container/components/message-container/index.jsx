import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import apiClient from "@/lib/api-client";
import {
  FETCH_ALL_MESSAGES_ROUTE,
  HOST,
  MESSAGE_TYPES,
  GET_CHANNEL_MESSAGES,
} from "@/lib/constants";
import { getColor } from "@/lib/utils";
import { useAppStore } from "@/store";
import moment from "moment";
import { useEffect, useRef, useState } from "react";
import { IoMdArrowRoundDown } from "react-icons/io";
import { IoCloseSharp } from "react-icons/io5";
import { MdFolderZip } from "react-icons/md";
import { MdMoreVert } from "react-icons/md";

const MessageContainer = () => {
  const [showImage, setShowImage] = useState(false);
  const [imageURL, setImageURL] = useState(null);
  const [showMenuForMessage, setShowMenuForMessage] = useState(null);
  const menuRef = useRef(null); 
  
  const {
    selectedChatData,
    setSelectedChatMessages,
    selectedChatMessages,
    selectedChatType,
    userInfo,
    setDownloadProgress,
    setIsDownloading,
    setRepliedMessage, // Add this from store
  } = useAppStore();
  const messageEndRef = useRef(null);

  useEffect(() => {
    const getMessages = async () => {
      const response = await apiClient.post(
        FETCH_ALL_MESSAGES_ROUTE,
        {
          id: selectedChatData._id,
        },
        { withCredentials: true }
      );

      if (response.data.messages) {
        setSelectedChatMessages(response.data.messages);
      }
    };

    const getChannelMessages = async () => {
      const response = await apiClient.get(
        `${GET_CHANNEL_MESSAGES}/${selectedChatData._id}`,
        { withCredentials: true }
      );
      if (response.data.messages) {
        setSelectedChatMessages(response.data.messages);
      }
    };

    if (selectedChatData._id) {
      if (selectedChatType === "contact") getMessages();
      else if (selectedChatType === "channel") getChannelMessages();
    }
  }, [selectedChatData, selectedChatType, setSelectedChatMessages]);

  useEffect(() => {
    if (messageEndRef.current) {
      messageEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [selectedChatMessages]);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setShowMenuForMessage(null);
      }
    };
  
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const checkIfImage = (filePath) => {
    const imageRegex =
      /\.(jpg|jpeg|png|gif|bmp|tiff|tif|webp|svg|ico|heic|heif)$/i;
    return imageRegex.test(filePath);
  };



  const handleReplyClick = (message) => {
    setRepliedMessage(message);
    setShowMenuForMessage(null); 
  };

  const toggleMenu = (messageId) => {
    setShowMenuForMessage(showMenuForMessage === messageId ? null : messageId);
  };

  const downloadFile = async (url) => {
    setIsDownloading(true);
    setDownloadProgress(0);
    const response = await apiClient.get(`${HOST}/${url}`, {
      responseType: "blob",
      onDownloadProgress: (progressEvent) => {
        const { loaded, total } = progressEvent;
        const percentCompleted = Math.round((loaded * 100) / total);
        setDownloadProgress(percentCompleted);
      },
    });
    const urlBlob = window.URL.createObjectURL(new Blob([response.data]));
    const link = document.createElement("a");
    link.href = urlBlob;
    link.setAttribute("download", url.split("/").pop());
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.URL.revokeObjectURL(urlBlob);
    setIsDownloading(false);
    setDownloadProgress(0);
  };

  const renderMessages = () => {
    let lastDate = null;
    return selectedChatMessages.map((message, index) => {
      const messageDate = moment(message.timestamp).format("YYYY-MM-DD");
      const showDate = messageDate !== lastDate;
      lastDate = messageDate;

      return (
        <div key={index} className="">
          {showDate && (
            <div className="text-center text-gray-500 my-2">
              {moment(message.timestamp).format("LL")}
            </div>
          )}
          {selectedChatType === "contact" && renderPersonalMessages(message)}
          {selectedChatType === "channel" && renderChannelMessages(message)}
        </div>
      );
    });
  };

  const renderPersonalMessages = (message) => {
    return (
      <div className="relative group">
        <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
          <button 
            onClick={() => toggleMenu(message._id)}
            className="text-gray-400 hover:text-white"
          >
            <MdMoreVert className="text-lg" />
          </button>
          
          {showMenuForMessage === message._id && (
            <div className="absolute right-0 mt-2 w-32 bg-[#2a2b33] rounded-md shadow-lg z-10">
              <button
                onClick={() => handleReplyClick(message)}
                className="block w-full px-4 py-2 text-sm text-left text-white hover:bg-[#3a3b43]"
              >
                Reply
              </button>
            </div>
          )}
        </div>
        <div
          className={`message ${
            message.sender === selectedChatData._id ? "text-left" : "text-right"
          }`}
        >
          {/* Reply Preview */}
          {message.replyTo && (
            <div
              className="bg-gray-700/30 p-2 rounded mb-2 text-sm italic border-l-4 border-blue-500"
              onClick={() => setRepliedMessage(message.replyTo)}
            >
              <span className="text-blue-400">Replying to:</span>{" "}
              {message.replyTo.content || "File attachment"}
            </div>
          )}

          {/* Message Content */}
          {message.messageType === MESSAGE_TYPES.TEXT && (
            <div
              className={`${
                message.sender !== selectedChatData._id
                  ? "bg-blue-600/80 ml-auto text-[#ffffff]/90"
                  : "bg-[#2a2b33]/50 text-white/80 border-[#ffffff]/20"
              } inline-block p-4 rounded my-1 max-w-[50%] break-words`}
            >
              {message.content}
            </div>
          )}

          {message.messageType === MESSAGE_TYPES.FILE && (
            <div
              className={`${
                message.sender !== selectedChatData._id
                  ? "bg-blue-600/80 ml-auto text-[#ffffff]/90"
                  : "bg-[#2a2b33]/50 text-white/80 border-[#ffffff]/20"
              } inline-block p-4 rounded my-1 lg:max-w-[50%] break-words`}
            >
              {checkIfImage(message.fileUrl) ? (
                <div
                  className="cursor-pointer"
                  onClick={() => {
                    setShowImage(true);
                    setImageURL(message.fileUrl);
                  }}
                >
                  <img
                    src={`${HOST}/${message.fileUrl}`}
                    alt=""
                    height={300}
                    width={300}
                  />
                </div>
              ) : (
                <div className="flex items-center justify-center gap-5">
                  <span className="text-white/80 text-3xl bg-black/20 rounded-full p-3">
                    <MdFolderZip />
                  </span>
                  <span>{message.fileUrl.split("/").pop()}</span>
                  <span
                    className="bg-black/20 p-3 text-2xl rounded-full hover:bg-black/50 cursor-pointer transition-all duration-300"
                    onClick={() => downloadFile(message.fileUrl)}
                  >
                    <IoMdArrowRoundDown />
                  </span>
                </div>
              )}
            </div>
          )}

          <div className="text-xs text-gray-600">
            {moment(message.timestamp).format("LT")}
          </div>
        </div>
      </div>
    );
  };

  const renderChannelMessages = (message) => {
    const isCurrentUser = message.sender._id === userInfo.id;
  
    return (
      <div className="relative group mt-5">
        {/* Add the three-dot menu for channel messages */}
        {!isCurrentUser && (
          <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
            <button 
              onClick={() => toggleMenu(message._id)}
              className="text-gray-400 hover:text-white p-1 rounded-full hover:bg-gray-700/20"
            >
              <MdMoreVert className="text-lg" />
            </button>
            
            {showMenuForMessage === message._id && (
              <div 
                ref={menuRef}
                className="absolute right-0 mt-2 w-32 bg-[#2a2b33] rounded-md shadow-lg z-10"
              >
                <button
                  onClick={() => handleReplyClick(message)}
                  className="block w-full px-4 py-2 text-sm text-left text-white hover:bg-[#3a3b43]"
                >
                  Reply
                </button>
              </div>
            )}
          </div>
        )}
  
        <div className={`${isCurrentUser ? "text-right" : "text-left"}`}>
          {/* Reply Preview */}
          {message.replyTo && (
            <div
              className="bg-gray-700/30 p-2 rounded mb-2 text-sm italic border-l-4 border-blue-500 cursor-pointer"
              onClick={() => setRepliedMessage(message.replyTo)}
            >
              <span className="text-blue-400">Replying to:</span>{" "}
              {message.replyTo.content || "File attachment"}
            </div>
          )}
  
          {/* Message Content */}
          <div
            className={`${
              isCurrentUser
                ? "bg-blue-600/80 ml-auto"
                : "bg-[#2a2b33]/50"
            } inline-block p-4 rounded my-1 max-w-[50%] break-words`}
          >
            {message.messageType === MESSAGE_TYPES.TEXT ? (
              message.content
            ) : (
              <>
                {checkIfImage(message.fileUrl) ? (
                  <div
                    className="cursor-pointer"
                    onClick={() => {
                      setShowImage(true);
                      setImageURL(message.fileUrl);
                    }}
                  >
                    <img
                      src={`${HOST}/${message.fileUrl}`}
                      alt="Attachment"
                      className="max-h-64 rounded-lg"
                    />
                  </div>
                ) : (
                  <div className="flex items-center justify-center gap-5">
                    <MdFolderZip className="text-3xl" />
                    <span className="truncate max-w-[120px]">
                      {message.fileUrl.split("/").pop()}
                    </span>
                    <button
                      className="p-2 rounded-full hover:bg-gray-700/20 transition-colors"
                      onClick={() => downloadFile(message.fileUrl)}
                    >
                      <IoMdArrowRoundDown className="text-xl" />
                    </button>
                  </div>
                )}
              </>
            )}
          </div>
  
          {/* Sender Info */}
          {!isCurrentUser && (
            <div className="flex items-center gap-2 mt-1">
              <Avatar className="h-8 w-8">
                {message.sender.image && (
                  <AvatarImage
                    src={`${HOST}/${message.sender.image}`}
                    className="rounded-full"
                  />
                )}
                <AvatarFallback
                  className={`uppercase ${getColor(message.sender.color)}`}
                >
                  {message.sender.firstName[0]}
                </AvatarFallback>
              </Avatar>
              <span className="text-sm text-white/60">
                {`${message.sender.firstName} ${message.sender.lastName}`}
              </span>
              <span className="text-xs text-white/60">
                {moment(message.timestamp).format("LT")}
              </span>
            </div>
          )}
  
          {/* Timestamp for current user's messages */}
          {isCurrentUser && (
            <div className="text-xs text-white/60 mt-1">
              {moment(message.timestamp).format("LT")}
            </div>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="flex-1 overflow-y-auto scrollbar-hidden p-4 px-8 md:w-[65vw] lg:w-[70vw] xl:w-[80vw] w-full">
      {selectedChatMessages.map((message, index) => {
        const messageDate = moment(message.timestamp).format("YYYY-MM-DD");
        const prevDate = index > 0 
          ? moment(selectedChatMessages[index-1].timestamp).format("YYYY-MM-DD")
          : null;
  
        return (
          <div key={message._id}>
            {messageDate !== prevDate && (
              <div className="text-center text-gray-500 my-2">
                {moment(message.timestamp).format("LL")}
              </div>
            )}
            
            {selectedChatType === "contact" 
              ? renderPersonalMessages(message)
              : renderChannelMessages(message)}
          </div>
        );
      })}
      <div ref={messageEndRef} />
      {showImage && (
        <div className="fixed inset-0 bg-black/90 flex items-center justify-center z-[1000]">
          <div className="relative max-w-4xl">
            <img
              src={`${HOST}/${imageURL}`}
              className="max-h-[90vh] rounded-lg"
              alt="Full preview"
            />
            <div className="absolute top-4 right-4 flex gap-2">
              <button
                className="p-2 bg-gray-800/50 rounded-full hover:bg-gray-700"
                onClick={() => downloadFile(imageURL)}
              >
                <IoMdArrowRoundDown className="text-xl" />
              </button>
              <button
                className="p-2 bg-gray-800/50 rounded-full hover:bg-gray-700"
                onClick={() => setShowImage(false)}
              >
                <IoCloseSharp className="text-xl" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MessageContainer;
