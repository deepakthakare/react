import Background from "@/assets/login.jpg";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import  apiClient  from "@/lib/api-client";
import { LOGIN_ROUTE, SIGNUP_ROUTE } from "@/lib/constants";
import { useState } from "react";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import { useAppStore } from "@/store";

const Auth = () => {
  const navigate = useNavigate();
  const { setUserInfo } = useAppStore();
  // Initialize state with empty strings
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  // Validate login form
  const validateLogin = () => {
    if (!email.trim().length) {
      toast.error("Email is required.");
      return false;
    }
    if (!password.trim().length) {
      toast.error("Password is required.");
      return false;
    }
    return true;
  };

  const validateSignup = () => {
    if (!email.length) {
      toast.error("Email is required.");
      return false;
    }
    if (!password.length) {
      toast.error("Password is required.");
      return false;
    }
    if (password !== confirmPassword) {
      toast.error("Password and Confirm Password should be same.");
      return false;
    }
    return true;
  };

  // Validate signup form
  const handleLogin = async () => {
    try {
      if (validateLogin()) {
        const response = await apiClient.post(
          LOGIN_ROUTE,
          { email, password },
          { withCredentials: true }
        );
        if (response.data.user.id) {
          setUserInfo(response.data.user);
          if (response.data.user.profileSetup) navigate("/chat");
          else navigate("/profile");
        } else {
          console.log("error");
        }
      }
    } catch (error) {
      console.log(error);
      toast.error("Email or Password does not match. Please try again.");
    }
  };

  // Handle login
  

  // Handle signup 
  const handleSignup = async () => {
    try {
      if (validateSignup()) {
        const response = await apiClient.post(
          SIGNUP_ROUTE,
          {
            email,
            password,
          },
        );
        if (response.status === 201) {
          setUserInfo(response.data.user);
          navigate("/profile");
        }
      }
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div className="h-screen w-screen flex items-center justify-center bg-gray-50">
      <div className="bg-white shadow-2xl rounded-3xl overflow-hidden grid xl:grid-cols-2 w-[90vw] max-w-6xl">
        {/* Left Side - Image Section */}
        {/* <div 
          className="hidden xl:block h-full bg-cover bg-center"
          style={{ backgroundImage: `url(${Background})` }}
        /> */}
        <div 
          className="hidden xl:flex justify-center items-center bg-cover bg-center"
          
        ><img src={Background} alt="backgorund-login" className="has-[700px]:"/></div>

        {/* Right Side - Content */}
        <div className="flex flex-col items-center justify-center p-8 space-y-8">
          {/* Welcome Header */}
          <div className="text-center space-y-4">
            <div className="flex items-center justify-center gap-4">
              <h1 className="text-4xl md:text-5xl font-bold text-gray-800">
                Welcome
              </h1>
            </div>
            <p className="text-gray-600 text-lg md:text-xl">
              Fill in the details to get started with the SMHFC chat app!
            </p>
          </div>

          {/* Tabs Section */}
          <div className="w-full max-w-md flex items-center justify-center">
            <Tabs defaultValue="login" className="w-full">
              <TabsList className="grid w-full grid-cols-2 bg-transparent">
                <TabsTrigger 
                  value="login" 
                  className="data-[state=active]:bg-transparent text-black text-opacity-90 border-b-2 rounded-none w-full data-[state=active]:text-black data-[state=active]:font-semibold data-[state=active]:border-b-lime-500 p-3 transition-all duration-300"
                >
                  Login
                </TabsTrigger>
                <TabsTrigger 
                  value="signup" 
                  className="data-[state=active]:bg-transparent text-black text-opacity-90 border-b-2 rounded-none w-full data-[state=active]:text-black data-[state=active]:font-semibold data-[state=active]:border-b-lime-500 p-3 transition-all duration-300"
                >
                  Signup
                </TabsTrigger>
              </TabsList>
              
              {/* Login Tab Content */}
              <TabsContent value="login" className="flex flex-col gap-5 mt-10">
                <Input 
                  placeholder="Email"
                  type="email"
                  className="rounded-full p-6"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                /> 
                <Input 
                  placeholder="Password"
                  type="password"
                  className="rounded-full p-6"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                /> 
                <Button 
                  className="rounded-full p-6 hover:bg-lime-600 text-white"
                  onClick={handleLogin}
                >
                  Login
                </Button>
              </TabsContent>
              
              {/* Signup Tab Content */}
              <TabsContent value="signup" className="flex flex-col gap-5 mt-10">
                <Input 
                  placeholder="Email"
                  type="email"
                  className="rounded-full p-6"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                /> 
                <Input 
                  placeholder="Password"
                  type="password"
                  className="rounded-full p-6"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                /> 
                <Input 
                  placeholder="Confirm Password"
                  type="password"
                  className="rounded-full p-6"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                /> 
                <Button 
                  className="rounded-full p-6 hover:bg-lime-600 text-white"
                  onClick={handleSignup}
                >
                  Signup
                </Button>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Auth;