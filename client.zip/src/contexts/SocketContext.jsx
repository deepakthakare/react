import { SOCKET_HOST } from "@/lib/constants";
import { useAppStore } from "@/store";
import React, { createContext, useContext, useEffect, useRef } from "react";
import { io } from "socket.io-client";

const SocketContext = createContext(null);

export const useSocket = () => useContext(SocketContext);

export const SocketProvider = ({ children }) => {
  const socket = useRef();
  const { userInfo } = useAppStore();

  // Unified notification handler
  const showNotification = (message, isChannel = false) => {
    const { addNotification, incrementUnread } = useAppStore.getState();
    const chatId = message.channelId || message.sender._id;
    
    // Browser Notification
    if (Notification.permission === "granted") {
      const title = isChannel ? "New Channel Message" : "New Message";
      const content = message.replyTo 
        ? `Reply from ${message.sender.firstName}: ${message.content}`
        : `${message.sender.firstName}: ${message.content}`;

      new Notification(title, {
        body: content,
        icon: message.sender.image || "/default-avatar.png",
      });
    }

    // In-App Notification
    incrementUnread(chatId);
    addNotification({
      id: Date.now(),
      chatId,
      message: message.content,
      isReply: !!message.replyTo,
      isChannel,
      sender: message.sender,
      timestamp: new Date(),
      read: false
    });
  };

  // Message handler with reply support
  const handleIncomingMessage = (message, isChannel = false) => {
    const { 
      selectedChatData, 
      selectedChatType,
      addMessage,
      resetUnread,
      addContactInDMContacts,
      addChannelInChannelLists
    } = useAppStore.getState();

    const currentChatId = selectedChatData?._id;
    const isCurrentChat = isChannel
      ? currentChatId === message.channelId
      : [message.sender._id, message.recipient?._id].includes(currentChatId);

    // Update messages if in current chat
    if (isCurrentChat) {
      addMessage(message);
      resetUnread(message.channelId || message.sender._id);
    }

    // Update contact/channel lists
    isChannel 
      ? addChannelInChannelLists(message)
      : addContactInDMContacts(message);

    // Show notification if not current user and not in chat
    if (message.sender._id !== userInfo.id && !isCurrentChat) {
      showNotification(message, isChannel);
    }
  };

  useEffect(() => {
    if (!userInfo?.id) return;

    const setupSocket = () => {
      socket.current = io(SOCKET_HOST, {
        withCredentials: true,
        query: { userId: userInfo.id },
        reconnectionAttempts: 3,
        timeout: 5000,
      });

      // Connection handlers
      socket.current.on("connect", () => {
        console.log("Socket connected:", socket.current.id);
      });

      socket.current.on("connect_error", (err) => {
        console.error("Socket connection error:", err.message);
      });

      // Message handlers
      socket.current.on("receiveMessage", (message) => 
        handleIncomingMessage(message, false)
      );

      socket.current.on("receive-channel-message", (message) => 
        handleIncomingMessage(message, true)
      );

      // Channel handlers
      socket.current.on("new-channel-added", (channel) => {
        useAppStore.getState().addChannel(channel);
      });

      socket.current.on("channel-updated", (channel) => {
        useAppStore.getState().updateChannel(channel);
      });
    };

    setupSocket();

    return () => {
      if (socket.current) {
        socket.current.off("receiveMessage");
        socket.current.off("receive-channel-message");
        socket.current.off("new-channel-added");
        socket.current.off("channel-updated");
        socket.current.disconnect();
      }
    };
  }, [userInfo?.id]);

  return (
    <SocketContext.Provider value={socket.current}>
      {children}
    </SocketContext.Provider>
  );
};

export default SocketProvider;  