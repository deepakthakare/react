import { SOCKET_HOST } from "@/lib/constants";
import { useAppStore } from "@/store";
import React, { createContext, useContext, useEffect, useRef } from "react";
import { io } from "socket.io-client";

const SocketContext = createContext(null);

export const useSocket = () => {
  return useContext(SocketContext);
};

export const SocketProvider = ({ children }) => {
  const socket = useRef();
  const { userInfo } = useAppStore();

  const showNotification = (message, isChannel = false) => {
    // Browser Notifications
    if (Notification.permission === "granted") {
      new Notification(isChannel ? "New Channel Message" : "New Message", {
        body: `${message.sender.firstName}: ${message.content}`,
        icon: message.sender.image || "/default-avatar.png",
      });
    }

    // In-App Notifications
    const { addNotification } = useAppStore.getState();
    addNotification({
      id: Date.now(),
      chatId: message.channelId || message.sender._id,
      message: `${message.sender.firstName}: ${message.content}`,
      isChannel,
      timestamp: new Date(),
      read: false
    });
  };

  useEffect(() => {
    if (userInfo) {
      socket.current = io(SOCKET_HOST, {
        withCredentials: true,
        query: { userId: userInfo.id },
      });

      socket.current.on("connect", () => {
        console.log("Connected to socket server");
      });

      const handleNotification = (message) => {
        const { 
          selectedChatData, 
          selectedChatType, 
          incrementUnread 
        } = useAppStore.getState();
        
        const chatId = message.channelId || message.sender._id;
        const isCurrentChat = (
          selectedChatType === 'contact' && selectedChatData?._id === message.sender._id
        ) || (
          selectedChatType === 'channel' && selectedChatData?._id === message.channelId
        );

        if (!isCurrentChat && message.sender._id !== userInfo.id) {
          incrementUnread(chatId);
          showNotification(message, !!message.channelId);
        }
      };

      const handleReceiveMessage = (message) => {
        const {
          selectedChatData: currentChatData,
          selectedChatType: currentChatType,
          addMessage,
          addContactInDMContacts,
          resetUnread,
        } = useAppStore.getState();

        const isCurrentChat = (
          currentChatType === 'contact' && 
          (currentChatData?._id === message.sender._id ||
           currentChatData?._id === message.recipient._id)
        );

        if (isCurrentChat) {
          addMessage(message);
          resetUnread(message.sender._id);
        }
        if (message.sender._id !== userInfo.id) {
          addContactInDMContacts(message);
        }
      };

      const handleReceiveChannelMessage = (message) => {
        const {
          selectedChatData,
          selectedChatType,
          addMessage,
          addChannelInChannelLists,
          resetUnread,
        } = useAppStore.getState();

        const isCurrentChat = (
          selectedChatType === 'channel' && 
          selectedChatData?._id === message.channelId
        );

        if (isCurrentChat) {
          addMessage(message);
          resetUnread(message.channelId);
        }
        addChannelInChannelLists(message);
      };

      const addNewChannel = (channel) => {
        const { addChannel } = useAppStore.getState();
        addChannel(channel);
      };

      const handleChannelUpdated = (updatedChannel) => {
        const { updateChannel } = useAppStore.getState();
        console.log("Channel updated:", updatedChannel);
        updateChannel(updatedChannel);
      };

      // Set up event listeners
      socket.current.on("receiveMessage", (message) => {
        handleReceiveMessage(message);
        handleNotification(message);
      });

      socket.current.on("recieve-channel-message", (message) => {
        handleReceiveChannelMessage(message);
        handleNotification(message);
      });

      socket.current.on("new-channel-added", addNewChannel);
      socket.current.on("channel-updated", handleChannelUpdated);

      return () => {
        socket.current.disconnect();
      };
    }
  }, [userInfo]);

  return (
    <SocketContext.Provider value={socket.current}>
      {children}
    </SocketContext.Provider>
  );
};

export default SocketProvider;