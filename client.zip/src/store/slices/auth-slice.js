/*export const createAuthSlice = (set) => ({
    userInfo: undefined,
    setUserInfo: (userInfo) => set({ userInfo }),
  }); */
  export const createAuthSlice = (set) => ({
    userInfo: undefined,
    
    // Ensure this sets the full user object
    setUserInfo: (userInfo) => set({ userInfo }),
    
    // Add a getter for role
    get role() {
      return this.userInfo?.role || 'user'; // Default to 'user' if role is missing
    }
  });
  
