import { useEffect } from 'react';
import { useAppStore } from '@/store';
import { toast } from 'sonner';

const NotificationHandler = () => {
  const { notifications, markAsRead } = useAppStore();

  useEffect(() => {
    notifications.forEach(notification => {
      if (!notification.read) {
        toast.message('New Message', {
          description: notification.message,
          duration: 5000,
        });
        markAsRead(notification.id);
      }
    });
  }, [notifications]);

  return null;
};

export default NotificationHandler;