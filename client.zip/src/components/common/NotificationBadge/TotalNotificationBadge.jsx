import { useAppStore } from '@/store';
import { FaEnvelope } from 'react-icons/fa';

const TotalNotificationBadge = () => {
  const unreadCounts = useAppStore(state => state.unreadCounts);
  const total = Object.values(unreadCounts).reduce((sum, count) => sum + count, 0);

  if (total === 0) return null;

  return (
    <div className="fixed top-4 right-4 flex items-center gap-2">
      {/* Message Icon */}
      <div className="relative">
        <FaEnvelope className="text-white text-2xl" />
        
        {/* Notification Count */}
        <div className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold">
          {total}
        </div>
      </div>
    </div>
  );
};

export default TotalNotificationBadge;