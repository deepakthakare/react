import { useAppStore } from "@/store";

export const CustomNotificationBadge = ({ chatId }) => {
  const unreadCount = useAppStore(state => state.unreadCounts[chatId] || 0);

  if (unreadCount === 0) return null;

  return (
    <div
      className="absolute right-4 top-1/2 -translate-y-1/2 bg-green-500 text-white rounded-full text-xs flex items-center justify-center"
      style={{
        width: '20px',
        height: '20px',
      }}
    >
      {unreadCount}
    </div>
  );
};