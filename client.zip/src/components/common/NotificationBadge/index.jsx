import { NotificationBadge } from 'react-notification-badge';
import { useAppStore } from '@/store';

export const ChatNotificationBadge = ({ chatId }) => {
  const unreadCount = useAppStore(state => state.unreadCounts[chatId] || 0);
  
  return (
    <NotificationBadge 
      count={unreadCount}
      effect={['scale']}
      style={{
        top: '-5px',
        right: '-5px',
        backgroundColor: '#4CAF50',
        color: 'white',
        fontSize: '12px',
        fontFamily: 'Arial',
      }}
    />
  );
};

export const TotalNotificationBadge = () => {
  const unreadCounts = useAppStore(state => state.unreadCounts);
  const total = Object.values(unreadCounts).reduce((sum, count) => sum + count, 0);

  return (
    <NotificationBadge 
      count={total}
      style={{ 
        backgroundColor: '#ff4757',
        top: '-2px',
        right: '-2px'
      }}
    />
  );
};