import { HOST } from "@/lib/constants";
import { getColor } from "@/lib/utils";
import { useAppStore } from "@/store";
import { Avatar, AvatarFallback, AvatarImage } from "@radix-ui/react-avatar";
import LogoGroup from "@/assets/group-icon.png";
import { FaEye } from 'react-icons/fa';

const ContactList = ({ contacts, isChannel = false }) => {
  const {
    selectedChatData,
    setSelectedChatType,
    setSelectedChatData,
    setSelectedChatMessages,
  } = useAppStore();

  const handleContactClick = (contact) => {
    console.log('Contact clicked!');
    if (isChannel) setSelectedChatType("channel");
    else setSelectedChatType("contact");
    setSelectedChatData(contact);
    if (selectedChatData && selectedChatData._id !== contact._id) {
      setSelectedChatMessages([]);
    }
  };

  const handleViewClick = (contact, event) => {
    event.stopPropagation(); // Stop event propagation to prevent parent click handler
    console.log('View icon clicked!', contact);
    // Add your logic for handling the view icon click here
  };

  return (
    <div className="mt-5">
      {contacts.map((contact, index) => (
        <div
          key={contact._id}
          className={`pl-10 py-2 transition-all duration-300 cursor-pointer ${
            selectedChatData && selectedChatData._id === contact._id
              ? "bg-[#4a720c] hover:bg-[#014aad]"
              : "hover:bg-[#f1f1f111]"
          }`}
          onClick={() => handleContactClick(contact)}
        >
          <div className="flex gap-5 items-center justify-start text-neutral-300">
            {!isChannel && (
              <Avatar className="h-10 w-10">
                {contact.image && (
                  <AvatarImage
                    src={`${HOST}/${contact.image}`}
                    alt="profile"
                    className="rounded-full bg-cover h-full w-full"
                  />
                )}
                <AvatarFallback
                  className={`uppercase ${
                    selectedChatData && selectedChatData._id === contact._id
                      ? "bg-[#ffffff22] border border-white/50"
                      : getColor(contact.color)
                  } h-10 w-10 flex items-center justify-center rounded-full`}
                >
                  {contact.firstName.split("").shift()}
                </AvatarFallback>
              </Avatar>
            )}
            {isChannel && (
              <div
                className={`bg-[#ffffff22] h-10 w-10 flex items-center justify-center rounded-full`}
              >
                <img src={LogoGroup} alt="group-icon" className="w-full sm:max-w-[90%]" />
              </div>
            )}
            {isChannel ? (
              <div className="flex items-center justify-between w-full pr-10">
                <span>{contact.name}</span>
                <span onClick={(event) => handleViewClick(contact, event)}>
                  <FaEye className="cursor-pointer" />
                </span>
              </div>
            ) : (
              <span>{`${contact.firstName} ${contact.lastName}`}</span>
            )}
          </div>
        </div>
      ))}
    </div>
  );
};

export default ContactList;