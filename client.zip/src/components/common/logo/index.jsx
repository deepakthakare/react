import LogoPrimary from "@/assets/logo.png";
const Logo = () => {
  return (
    <div className="flex p-5  justify-start items-center gap-2">
      <img src={LogoPrimary} alt="chat-logo" className="w-64 sm:w-40 md:w-48 lg:w-56 xl:w-64"/>
    </div>
  );
};

export default Logo;
