import mongoose from "mongoose";
import bcrypt from "bcrypt";

const userSchema = new mongoose.Schema({
  email: {
    type: String,
    required: [true, "Email is Required"],
    unique: true,
  },
  password: {
    type: String,
    required: [true, "Password is Required"],
  },
  firstName: {
    type: String,
    required: false,
  },
  lastName: {
    type: String,
    required: false,
  },
  image: {
    type: String,
    required: false,
  },
  profileSetup: {
    type: Boolean,
    default: false,
  },
  color: {
    type: Number,
    required: false,
  },
  // Add role field here
  role: {
    type: String,
    enum: ['user', 'superuser'], // Allowed values
    default: 'user' // Default role
  }
});

userSchema.pre("save", async function (next) {
  // Only hash password if it's modified
  if (!this.isModified('password')) return next();
  
  const salt = await bcrypt.genSalt();
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

userSchema.statics.login = async function (email, password) {
  if (!email || !password) {
    throw new Error("All fields must be filled");
  }

  const user = await this.findOne({ email });
  if (!user) {
    throw new Error("Invalid login credentials");
  }

  const auth = await bcrypt.compare(password, user.password);
  if (!auth) {
    throw new Error("Invalid login credentials");
  }

  // Return user with role information
  return user;
};

const User = mongoose.model("Users", userSchema);
export default User;