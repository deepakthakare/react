import mongoose from "mongoose";
import bcrypt from "bcrypt";

const userSchema = new mongoose.Schema({
  email: {
    type: String,
    required: [true, "Email is Required"],
    unique: true,
  },
  password: {
    type: String,
    required: [true, "Password is Required"],
  },
  firstName: {
    type: String,
    required: false,
  },
  lastName: {
    type: String,
    required: false,
  },
  image: {
    type: String,
    required: false,
  },
  profileSetup: {
    type: Boolean,
    default: false,
  },
  color: {
    type: Number,
    required: false,
  },
});

userSchema.pre("save", async function (next) {
  const salt = await bcrypt.genSalt();
  this.password = await bcrypt.hash(this.password, salt);
  next();
});


userSchema.statics.login = async function (email, password) {
  // Basic validation for empty fields
  if (!email || !password) {
    throw new Error("All fields must be filled");
  }

  // Find user by email
  const user = await this.findOne({ email });
  if (!user) {
    throw new Error("Invalid login credentials"); // Generic error
  }

  // Compare passwords
  const auth = await bcrypt.compare(password, user.password);
  if (!auth) {
    throw new Error("Invalid login credentials"); // Same generic error
  }

  return user;
};

const User = mongoose.model("Users", userSchema);
export default User;
