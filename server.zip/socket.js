import { Server as SocketIOServer } from "socket.io";
import mongoose from "mongoose";
import Message from "./model/MessagesModel.js";
import Channel from "./model/ChannelModel.js";

const setupSocket = (server) => {
  const io = new SocketIOServer(server, {
    cors: {
      origin: process.env.ORIGIN,
      methods: ["GET", "POST"],
      credentials: true,
    },
    connectionStateRecovery: {
      maxDisconnectionDuration: 2 * 60 * 1000, // 2 minutes
      skipMiddlewares: true,
    },
  });

  const userSocketMap = new Map();
  let heartbeatInterval;

  // Connection validation middleware
  io.use((socket, next) => {
    const userId = socket.handshake.query.userId;
    
    if (!userId) {
      return next(new Error("Authentication error: User ID required"));
    }
    
    if (!mongoose.Types.ObjectId.isValid(userId)) {
      return next(new Error("Invalid user ID format"));
    }

    next();
  });

  // Heartbeat system
  const startHeartbeat = () => {
    heartbeatInterval = setInterval(() => {
      const now = Date.now();
      io.sockets.sockets.forEach((socket) => {
        // Disconnect sockets older than 2 minutes without heartbeat
        if (now - (socket.lastPing || 0) > 120000) {
          socket.disconnect(true);
          console.log(`Disconnected stale connection: ${socket.id}`);
        }
      });
    }, 30000); // Check every 30 seconds
  };

  const stopHeartbeat = () => {
    if (heartbeatInterval) {
      clearInterval(heartbeatInterval);
    }
  };

  const addChannelNotify = async (channel) => {
    if (channel?.members) {
      channel.members.forEach((member) => {
        const socketId = userSocketMap.get(member.toString());
        socketId && io.to(socketId).emit("new-channel-added", channel);
      });
    }
  };

  const updateChannelNotify = async (channel) => {
    if (channel?.members) {
      channel.members.forEach((member) => {
        const socketId = userSocketMap.get(member.toString());
        socketId && io.to(socketId).emit("channel-updated", channel);
      });
    }
  };

  const sendMessage = async (message) => {
    try {
      const createdMessage = await Message.create({
        ...message,
        replyTo: message.replyTo || null,
      });

      const messageData = await Message.findById(createdMessage._id)
        .populate("sender", "id email firstName lastName image color")
        .populate("recipient", "id email firstName lastName image color")
        .populate({
          path: "replyTo",
          select: "content fileUrl sender",
          populate: { path: "sender", select: "firstName lastName" },
        })
        .lean();

      const recipientSocketId = userSocketMap.get(message.recipient);
      const senderSocketId = userSocketMap.get(message.sender);

      [recipientSocketId, senderSocketId].forEach(socketId => {
        if (socketId && io.sockets.sockets.has(socketId)) {
          io.to(socketId).emit("receiveMessage", messageData);
        }
      });
    } catch (error) {
      console.error("Error sending message:", error);
    }
  };

  const sendChannelMessage = async (message) => {
    try {
      const createdMessage = await Message.create({
        sender: message.sender,
        content: message.content,
        messageType: message.messageType,
        fileUrl: message.fileUrl,
        replyTo: message.replyTo || null,
        timestamp: new Date()
      });

      const messageData = await Message.findById(createdMessage._id)
        .populate("sender", "id email firstName lastName image color")
        .populate({
          path: "replyTo",
          select: "content fileUrl sender",
          populate: { path: "sender", select: "firstName lastName" },
        })
        .lean();

      const channel = await Channel.findByIdAndUpdate(
        message.channelId,
        { $push: { messages: createdMessage._id } },
        { new: true }
      )
        .populate("members")
        .populate("admin", "id email firstName lastName image color role");

      const finalData = {
        ...messageData,
        channelId: channel._id,
        sender: {
          ...messageData.sender,
          role: channel.admin._id.equals(messageData.sender._id) ? "admin" : "member"
        }
      };

      const emitTo = [
        ...channel.members.map(m => m._id.toString()),
        channel.admin._id.toString()
      ];

      emitTo.forEach(userId => {
        const socketId = userSocketMap.get(userId);
        if (socketId && io.sockets.sockets.has(socketId)) {
          io.to(socketId).emit("receive-channel-message", finalData);
        }
      });
    } catch (error) {
      console.error("Error sending channel message:", error);
    }
  };

  const handleDisconnect = (socket) => {
    console.log("Client disconnected:", socket.id);
    for (const [userId, socketId] of userSocketMap.entries()) {
      if (socketId === socket.id) {
        userSocketMap.delete(userId);
        break;
      }
    }
  };

  io.on("connection", (socket) => {
    console.log("New connection:", socket.id);
    socket.lastPing = Date.now();

    // Setup ping/pong
    socket.on("ping", (cb) => {
      socket.lastPing = Date.now();
      typeof cb === "function" && cb(Date.now());
    });

    const userId = socket.handshake.query.userId;
    if (userId) {
      userSocketMap.set(userId, socket.id);
      console.log(`User ${userId} connected with socket ${socket.id}`);
    }

    // Event handlers
    socket.on("add-channel-notify", addChannelNotify);
    socket.on("sendMessage", sendMessage);
    socket.on("channel-updated", updateChannelNotify);
    socket.on("send-channel-message", sendChannelMessage);
    socket.on("disconnect", () => handleDisconnect(socket));
  });

  // Start heartbeat system
  startHeartbeat();

  // Cleanup on server shutdown
  server.on("close", () => {
    stopHeartbeat();
    console.log("Socket server shutdown");
  });

  return io;
};

export default setupSocket;