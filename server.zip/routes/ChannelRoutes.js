import { Router } from "express";
import {
  createChannel,
  getChannelMessages,
  getUserChannels,
  getChannelDetails,
  updateChannel
} from "../controllers/ChannelControllers.js";
import { verifyToken } from "../middlewares/AuthMiddleware.js";
import roleMiddleware from "../middlewares/RoleMiddleware.js"; 

const channelRoutes = Router();

channelRoutes.post(
  "/create-channel", 
  verifyToken,
  roleMiddleware('superuser'),
  createChannel
);
channelRoutes.get("/get-user-channels", verifyToken, getUserChannels);
channelRoutes.get("/details/:id", verifyToken, getChannelDetails);
channelRoutes.put("/update/:id", verifyToken, updateChannel);
channelRoutes.get(
  "/get-channel-messages/:channelId",
  verifyToken,
  getChannelMessages
);

export default channelRoutes;
